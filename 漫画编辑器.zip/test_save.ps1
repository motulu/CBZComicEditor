# 测试保存功能
$src = "E:\moyulu\本地化媒体库\漫画\刮削数据\601.cbz"
$test = "E:\moyulu\本地化媒体库\漫画\刮削数据\601_test.cbz"
$dll = "E:\moyulu\本地化媒体库\资料库\漫画编辑器\bin\Debug\net8.0-windows\ComicInfoEditor.dll"

if (Test-Path $test) { Remove-Item $test -Force }
Copy-Item $src $test

Add-Type -Path $dll

$service = New-Object ComicInfoEditor.Services.CbzService
$ci = New-Object ComicInfoEditor.Models.ComicInfo
$ci.Series = "TestMySeries"
$ci.Writer = "TestWriter"
$ci.Title = "TestTitle"
$ci.Number = "1"
$ci.Characters = "PersonA[Tag1,Tag2],PersonB[]"

Write-Host "=== Saving ==="
$service.SaveComicInfo($test, $ci, $false)
Write-Host "Save done"

Write-Host "=== Loading ==="
$loaded = $service.LoadComicInfo($test)
Write-Host "Series: $($loaded.Series)"
Write-Host "Writer: $($loaded.Writer)"
Write-Host "Title: $($loaded.Title)"
Write-Host "Number: $($loaded.Number)"
Write-Host "CharactersTags: $($loaded.Characters)"

Write-Host "=== Extracting ComicInfo.xml ==="
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($test)
$entry = $zip.Entries | Where-Object { $_.Name -eq "ComicInfo.xml" } | Select-Object -First 1
if ($entry) {
    $stream = $entry.Open()
    $reader = New-Object System.IO.StreamReader($stream)
    $content = $reader.ReadToEnd()
    $reader.Close()
    $stream.Close()
    Write-Host "ComicInfo.xml content ($($content.Length) chars):"
    Write-Host $content
} else {
    Write-Host "No ComicInfo.xml found in CBZ!"
}
$zip.Dispose()

Remove-Item $test -Force
Write-Host "Test done"
using ComicInfoEditor.ViewModels;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ComicInfoEditor;

public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;
    private CancellationTokenSource? _loadDebounceCts;
    private bool _isShiftDragging;
    private int _dragStartIndex = -1;
    private bool _suppressFileSelectionChanged;

    public MainWindow()
    {
        InitializeComponent();
        _viewModel = new MainViewModel();
        DataContext = _viewModel;

        _viewModel.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(MainViewModel.IsFullScreen))
            {
                if (_viewModel.IsFullScreen)
                {
                    WindowStyle = WindowStyle.None;
                    WindowState = WindowState.Maximized;
                }
                else
                {
                    WindowStyle = WindowStyle.SingleBorderWindow;
                    WindowState = WindowState.Normal;
                }
            }
        };
    }

    private async void FileListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_viewModel.IsLoading || _suppressFileSelectionChanged) return;

        if (sender is ListBox listBox)
        {
            _viewModel.SelectedCbzFiles.Clear();
            foreach (var item in listBox.SelectedItems)
            {
                if (item is CbzFileItem fileItem)
                {
                    _viewModel.SelectedCbzFiles.Add(fileItem);
                }
            }

            _viewModel.IsBatchMode = _viewModel.SelectedCbzFiles.Count > 1;

            if (listBox.SelectedItem is CbzFileItem selectedFile)
            {
                _viewModel.SelectedCbzFile = selectedFile;

                // 防抖：取消之前的加载请求，延迟 300ms 后只加载最后一次选择
                _loadDebounceCts?.Cancel();
                _loadDebounceCts = new CancellationTokenSource();
                var token = _loadDebounceCts.Token;

                try
                {
                    await Task.Delay(300, token);
                    if (!token.IsCancellationRequested)
                    {
                        await _viewModel.LoadComicInfoForSelectedCommand.ExecuteAsync(null);
                    }
                }
                catch (TaskCanceledException)
                {
                    // 被取消，忽略
                }
            }
        }
    }

    // 字典面板：点击遮罩关闭
    private void DictionaryOverlay_MouseDown(object sender, MouseButtonEventArgs e)
    {
        _viewModel.OpenDictionaryCommand.Execute(null);
    }

    // 字典面板：阻止事件冒泡
    private void DictionaryPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
    }

    // 字典输入框：回车添加
    private void DictionaryInput_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
        {
            _viewModel.AddDictionaryValueCommand.Execute(null);
            e.Handled = true;
        }
    }

    // 字典面板：删除多选条目
    private async void DeleteDictionarySelected_Click(object sender, RoutedEventArgs e)
    {
        var selectedItems = DictionaryListBox.SelectedItems.Cast<string>().ToList();
        if (selectedItems.Count == 0)
        {
            MessageBox.Show("请先选择要删除的条目", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        await _viewModel.DeleteDictionaryValuesAsync(selectedItems);
    }

    // ========== Shift+拖动多选功能 ==========

    private void ListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is ListBox listBox && Keyboard.Modifiers == ModifierKeys.Shift)
        {
            _isShiftDragging = true;
            _suppressFileSelectionChanged = true;
            var item = GetItemAtPosition(listBox, e.GetPosition(listBox));
            _dragStartIndex = item != null ? listBox.Items.IndexOf(item) : -1;

            if (_dragStartIndex >= 0)
            {
                listBox.Focus();
                listBox.SelectedItems.Add(listBox.Items[_dragStartIndex]);
            }
            e.Handled = true;
        }
    }

    private void ListBox_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (!_isShiftDragging || sender is not ListBox listBox) return;

        var item = GetItemAtPosition(listBox, e.GetPosition(listBox));
        if (item == null) return;

        int endIndex = listBox.Items.IndexOf(item);
        if (endIndex < 0 || endIndex == _dragStartIndex) return;

        int from = Math.Min(_dragStartIndex, endIndex);
        int to = Math.Max(_dragStartIndex, endIndex);

        for (int i = from; i <= to; i++)
        {
            if (!listBox.SelectedItems.Contains(listBox.Items[i]))
                listBox.SelectedItems.Add(listBox.Items[i]);
        }
    }

    private void ListBox_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!_isShiftDragging) return;

        _isShiftDragging = false;
        _dragStartIndex = -1;
        _suppressFileSelectionChanged = false;

        // 拖动结束后，如果是文件列表，触发数据加载
        if (sender is ListBox listBox && listBox == FileListBox)
        {
            FileListBox_SelectionChanged(listBox, null!);
        }
    }

    private static object? GetItemAtPosition(ListBox listBox, Point position)
    {
        var element = listBox.InputHitTest(position) as DependencyObject;
        while (element != null)
        {
            if (element is ListBoxItem lbi)
            {
                return lbi.Content;
            }
            element = VisualTreeHelper.GetParent(element);
        }
        return null;
    }
}
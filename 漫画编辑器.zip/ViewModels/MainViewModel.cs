using ComicInfoEditor.Models;
using ComicInfoEditor.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace ComicInfoEditor.ViewModels
{
    public partial class MainViewModel : BaseViewModel
    {
        private readonly ICbzService _cbzService;
        private readonly IHistoryService _historyService;

        // 文件列表
        [ObservableProperty]
        private ObservableCollection<CbzFileItem> _cbzFiles = new();

        [ObservableProperty]
        private CbzFileItem? _selectedCbzFile;

        [ObservableProperty]
        private ObservableCollection<CbzFileItem> _selectedCbzFiles = new();

        // 当前编辑的ComicInfo
        [ObservableProperty]
        private ComicInfo? _currentComicInfo;

        // 字段属性
        [ObservableProperty] private string _series = string.Empty;
        [ObservableProperty] private string _localizedSeries = string.Empty;
        [ObservableProperty] private string _seriesSort = string.Empty;
        [ObservableProperty] private string _writer = string.Empty;
        [ObservableProperty] private string _publisher = string.Empty;
        [ObservableProperty] private string _translator = string.Empty;
        [ObservableProperty] private string _title = string.Empty;
        [ObservableProperty] private string _number = string.Empty;
        [ObservableProperty] private string _count = string.Empty;
        [ObservableProperty] private string _volume = string.Empty;
        [ObservableProperty] private string _storyArc = string.Empty;
        [ObservableProperty] private string _storyArcNumber = string.Empty;
        [ObservableProperty] private string _seriesGroup = string.Empty;
        [ObservableProperty] private string _relatedWorks = string.Empty;
        [ObservableProperty] private string _summary = string.Empty;
        [ObservableProperty] private string _notes = string.Empty;
        [ObservableProperty] private string _genre = string.Empty;
        [ObservableProperty] private string _tags = string.Empty;
        [ObservableProperty] private string _web = string.Empty;
        [ObservableProperty] private string _pageCount = string.Empty;
        [ObservableProperty] private string _year = string.Empty;
        [ObservableProperty] private string _month = string.Empty;
        [ObservableProperty] private string _day = string.Empty;

        // 相关作品
        [ObservableProperty]
        private ObservableCollection<RelatedWorkEntry> _relatedWorkEntries = new();

        // 自定义字段
        [ObservableProperty]
        private ObservableCollection<CustomFieldItem> _customFields = new();

        // 状态
        [ObservableProperty] private bool _isLoading;
        [ObservableProperty] private string _statusText = "就绪";
        [ObservableProperty] private bool _isBatchMode;
        [ObservableProperty] private string _currentFilePath = string.Empty;
        [ObservableProperty] private bool _isFullScreen;
        [ObservableProperty] private string _windowTitle = "CBZ漫画编辑器";

        // 历史记录下拉
        [ObservableProperty] private ObservableCollection<string> _writerHistory = new();
        [ObservableProperty] private ObservableCollection<string> _publisherHistory = new();
        [ObservableProperty] private ObservableCollection<string> _translatorHistory = new();
        [ObservableProperty] private ObservableCollection<string> _genreHistory = new();
        [ObservableProperty] private ObservableCollection<string> _tagsHistory = new();

        // 字典管理
        [ObservableProperty] private bool _isDictionaryOpen;
        [ObservableProperty] private string _dictionaryFieldName = "Writer";
        [ObservableProperty] private string _dictionaryFieldDisplayName = "作者";
        [ObservableProperty] private string _newDictionaryValue = string.Empty;
        [ObservableProperty] private ObservableCollection<string> _dictionaryValues = new();

        // 字典字段列表（实例属性，用于XAML绑定）
        [ObservableProperty]
        private ObservableCollection<DictionaryFieldItem> _dictionaryFieldItems = new()
        {
            new DictionaryFieldItem { FieldName = "Writer", DisplayName = "作者" },
            new DictionaryFieldItem { FieldName = "Publisher", DisplayName = "社团/出版社" },
            new DictionaryFieldItem { FieldName = "Translator", DisplayName = "翻译" },
            new DictionaryFieldItem { FieldName = "Genre", DisplayName = "分类" },
            new DictionaryFieldItem { FieldName = "Tags", DisplayName = "标签" },
        };

        public MainViewModel()
        {
            _cbzService = new CbzService();
            _historyService = new HistoryService();
            _historyService.Initialize();
        }

        public MainViewModel(ICbzService cbzService, IHistoryService historyService)
        {
            _cbzService = cbzService;
            _historyService = historyService;
            _historyService.Initialize();
        }

        [RelayCommand]
        private async Task OpenSingleFile()
        {
            var dlg = new OpenFileDialog
            {
                Title = "打开CBZ文件",
                Filter = "CBZ文件 (*.cbz)|*.cbz|ZIP文件 (*.zip)|*.zip|所有文件 (*.*)|*.*",
                Multiselect = false
            };

            if (dlg.ShowDialog() == true)
            {
                await LoadFiles(new[] { dlg.FileName });
            }
        }

        [RelayCommand]
        private async Task OpenFolder()
        {
            var dlg = new OpenFolderDialog
            {
                Title = "选择包含CBZ文件的文件夹"
            };

            if (dlg.ShowDialog() == true)
            {
                var cbzFiles = Directory.GetFiles(dlg.FolderName, "*.cbz", SearchOption.AllDirectories);
                var zipFiles = Directory.GetFiles(dlg.FolderName, "*.zip", SearchOption.AllDirectories);
                var allFiles = cbzFiles.Concat(zipFiles).Distinct().ToArray();
                await LoadFiles(allFiles);
            }
        }

        private async Task LoadFiles(string[] filePaths)
        {
            IsLoading = true;
            StatusText = "正在加载文件...";
            CbzFiles.Clear();
            SelectedCbzFiles.Clear();

            await Task.Run(() =>
            {
                foreach (var path in filePaths)
                {
                    var item = new CbzFileItem
                    {
                        FilePath = path,
                        FileName = Path.GetFileName(path),
                        DirectoryName = Path.GetDirectoryName(path) ?? string.Empty
                    };
                    Application.Current.Dispatcher.Invoke(() => CbzFiles.Add(item));
                }
            });

            if (CbzFiles.Count > 0)
            {
                SelectedCbzFile = CbzFiles[0];
                SelectedCbzFiles.Add(CbzFiles[0]);
                await LoadComicInfoForSelected();
            }

            IsLoading = false;
            StatusText = $"已加载 {CbzFiles.Count} 个文件";
            UpdateWindowTitle();
        }

        [RelayCommand]
        private async Task LoadComicInfoForSelected()
        {
            if (SelectedCbzFile == null) return;

            IsLoading = true;
            StatusText = "正在加载元数据...";

            try
            {
                var comicInfo = await _cbzService.LoadComicInfoAsync(SelectedCbzFile.FilePath);
                CurrentComicInfo = comicInfo;

                Series = comicInfo.Series;
                LocalizedSeries = comicInfo.LocalizedSeries;
                SeriesSort = comicInfo.SeriesSort;
                Writer = comicInfo.Writer;
                Publisher = comicInfo.Publisher;
                Translator = comicInfo.Translator;
                Title = comicInfo.Title;
                Number = comicInfo.Number;
                Count = comicInfo.Count;
                Volume = comicInfo.Volume;
                StoryArc = comicInfo.StoryArc;
                StoryArcNumber = comicInfo.StoryArcNumber;
                SeriesGroup = comicInfo.SeriesGroup;
                RelatedWorks = comicInfo.RelatedWorks;
                Summary = comicInfo.Summary;
                Notes = comicInfo.Notes;
                Genre = comicInfo.Genre;
                Tags = comicInfo.Tags;
                Web = comicInfo.Web;
                PageCount = comicInfo.PageCount == 0 ? string.Empty : comicInfo.PageCount.ToString();
                Year = comicInfo.Year == 0 ? string.Empty : comicInfo.Year.ToString();
                Month = comicInfo.Month == 0 ? string.Empty : comicInfo.Month.ToString();
                Day = comicInfo.Day == 0 ? string.Empty : comicInfo.Day.ToString();

                RelatedWorkEntries = new ObservableCollection<RelatedWorkEntry>(
                    RelatedWorkEntry.Parse(comicInfo.RelatedWorks));

                CustomFields.Clear();
                if (comicInfo.CustomFields != null)
                {
                    foreach (var field in comicInfo.CustomFields)
                    {
                        CustomFields.Add(new CustomFieldItem
                        {
                            FieldName = field.Name,
                            FieldValue = field.InnerText
                        });
                    }
                }

                CurrentFilePath = SelectedCbzFile.FilePath;
                StatusText = "元数据加载完成";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载元数据失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                StatusText = "加载失败";
            }
            finally
            {
                IsLoading = false;
            }

            // 自动将CBZ中的数据保存到字典
            SaveHistoryToDictionary();

            await LoadHistoryData();
        }

        private async Task LoadHistoryData()
        {
            WriterHistory = new ObservableCollection<string>(await _historyService.GetFieldHistoryAsync("Writer"));
            PublisherHistory = new ObservableCollection<string>(await _historyService.GetFieldHistoryAsync("Publisher"));
            TranslatorHistory = new ObservableCollection<string>(await _historyService.GetFieldHistoryAsync("Translator"));
            GenreHistory = new ObservableCollection<string>(await _historyService.GetFieldHistoryAsync("Genre"));
            TagsHistory = new ObservableCollection<string>(await _historyService.GetFieldHistoryAsync("Tags"));
        }

        [RelayCommand]
        private async Task SaveComicInfo()
        {
            if (SelectedCbzFile == null)
            {
                MessageBox.Show("请先选择一个CBZ文件", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            IsLoading = true;
            StatusText = "正在保存...";

            try
            {
                await ApplyToComicInfo();

                foreach (var file in SelectedCbzFiles)
                {
                    await _cbzService.SaveComicInfoAsync(file.FilePath, CurrentComicInfo!);
                }

                StatusText = "保存成功";
            }
            catch (Exception ex)
            {
                var msg = $"保存失败: {ex.Message}";
                var inner = ex.InnerException;
                while (inner != null)
                {
                    msg += $"\n→ {inner.Message}";
                    inner = inner.InnerException;
                }
                MessageBox.Show(msg, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                StatusText = "保存失败";
            }
            finally
            {
                IsLoading = false;
            }
        }

        private Task ApplyToComicInfo()
        {
            if (CurrentComicInfo == null)
                CurrentComicInfo = new ComicInfo();

            CurrentComicInfo.Series = Series;
            CurrentComicInfo.LocalizedSeries = LocalizedSeries;
            CurrentComicInfo.SeriesSort = SeriesSort;
            CurrentComicInfo.Writer = Writer;
            CurrentComicInfo.Publisher = Publisher;
            CurrentComicInfo.Translator = Translator;
            CurrentComicInfo.Title = Title;
            CurrentComicInfo.Number = Number;
            CurrentComicInfo.Count = Count;
            CurrentComicInfo.Volume = Volume;
            CurrentComicInfo.StoryArc = StoryArc;
            CurrentComicInfo.StoryArcNumber = StoryArcNumber;
            CurrentComicInfo.SeriesGroup = SeriesGroup;
            CurrentComicInfo.RelatedWorks = RelatedWorkEntry.ToString(RelatedWorkEntries.ToList());
            CurrentComicInfo.Summary = Summary;
            CurrentComicInfo.Notes = Notes;
            CurrentComicInfo.Genre = Genre;
            CurrentComicInfo.Tags = Tags;
            CurrentComicInfo.Web = Web;
            CurrentComicInfo.PageCount = int.TryParse(PageCount, out var pc) ? pc : 0;
            CurrentComicInfo.Year = int.TryParse(Year, out var y) ? y : 0;
            CurrentComicInfo.Month = int.TryParse(Month, out var m) ? m : 0;
            CurrentComicInfo.Day = int.TryParse(Day, out var d) ? d : 0;

            CurrentComicInfo.CustomFields.Clear();
            foreach (var custom in CustomFields)
            {
                var doc = new System.Xml.XmlDocument();
                var elem = doc.CreateElement(custom.FieldName);
                elem.InnerText = custom.FieldValue;
                CurrentComicInfo.CustomFields.Add(elem);
            }

            SaveHistory();

            return Task.CompletedTask;
        }

        /// <summary>
        /// 将逗号分隔的字符串拆分为独立条目后保存到历史记录
        /// </summary>
        private List<string> SplitCommaSeparated(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return new List<string>();
            return value.Split(',')
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrEmpty(s))
                .Distinct()
                .ToList();
        }

        private async void SaveHistory()
        {
            // 按逗号分隔保存 - 作者
            foreach (var item in SplitCommaSeparated(Writer))
                await _historyService.AddFieldHistoryAsync("Writer", item);
            // 按逗号分隔保存 - 出版社
            foreach (var item in SplitCommaSeparated(Publisher))
                await _historyService.AddFieldHistoryAsync("Publisher", item);
            // 按逗号分隔保存 - 翻译
            foreach (var item in SplitCommaSeparated(Translator))
                await _historyService.AddFieldHistoryAsync("Translator", item);
            // 按逗号分隔保存 - 分类
            foreach (var item in SplitCommaSeparated(Genre))
                await _historyService.AddFieldHistoryAsync("Genre", item);
            // 按逗号分隔保存 - 标签
            foreach (var item in SplitCommaSeparated(Tags))
                await _historyService.AddFieldHistoryAsync("Tags", item);
            // 按逗号分隔保存 - 系列
            foreach (var item in SplitCommaSeparated(SeriesGroup))
                await _historyService.AddFieldHistoryAsync("SeriesGroup", item);
            // 按逗号分隔保存 - 链接
            foreach (var item in SplitCommaSeparated(Web))
                await _historyService.AddFieldHistoryAsync("Web", item);

            // 保存相关作品名称历史
            foreach (var rw in RelatedWorkEntries)
            {
                if (!string.IsNullOrWhiteSpace(rw.WorkName))
                    await _historyService.AddFieldHistoryAsync("RelatedWork", rw.WorkName);
                if (!string.IsNullOrWhiteSpace(rw.Relation))
                    await _historyService.AddFieldHistoryAsync("RelatedWorkRelation", rw.Relation);
            }
        }

        // 加载CBZ时自动将数据保存到字典（不触发，纯后台保存）
        private async void SaveHistoryToDictionary()
        {
            foreach (var item in SplitCommaSeparated(Writer))
                await _historyService.AddFieldHistoryAsync("Writer", item);
            foreach (var item in SplitCommaSeparated(Publisher))
                await _historyService.AddFieldHistoryAsync("Publisher", item);
            foreach (var item in SplitCommaSeparated(Translator))
                await _historyService.AddFieldHistoryAsync("Translator", item);
            foreach (var item in SplitCommaSeparated(Genre))
                await _historyService.AddFieldHistoryAsync("Genre", item);
            foreach (var item in SplitCommaSeparated(Tags))
                await _historyService.AddFieldHistoryAsync("Tags", item);
            foreach (var item in SplitCommaSeparated(SeriesGroup))
                await _historyService.AddFieldHistoryAsync("SeriesGroup", item);
            foreach (var item in SplitCommaSeparated(Web))
                await _historyService.AddFieldHistoryAsync("Web", item);
            foreach (var rw in RelatedWorkEntries)
            {
                if (!string.IsNullOrWhiteSpace(rw.WorkName))
                    await _historyService.AddFieldHistoryAsync("RelatedWork", rw.WorkName);
                if (!string.IsNullOrWhiteSpace(rw.Relation))
                    await _historyService.AddFieldHistoryAsync("RelatedWorkRelation", rw.Relation);
            }
        }

        [RelayCommand]
        private void AddRelatedWork()
        {
            RelatedWorkEntries.Add(new RelatedWorkEntry { WorkName = "作品名", Relation = "关系" });
        }

        [RelayCommand]
        private void RemoveRelatedWork(RelatedWorkEntry? work)
        {
            if (work != null)
                RelatedWorkEntries.Remove(work);
        }

        [RelayCommand]
        private void AddCustomField()
        {
            CustomFields.Add(new CustomFieldItem { FieldName = "新字段", FieldValue = string.Empty });
        }

        [RelayCommand]
        private void RemoveCustomField(CustomFieldItem? field)
        {
            if (field != null)
                CustomFields.Remove(field);
        }

        [RelayCommand]
        private void ToggleFullScreen()
        {
            IsFullScreen = !IsFullScreen;
        }

        // ========== 字典管理 ==========

        [RelayCommand]
        private void OpenDictionary()
        {
            IsDictionaryOpen = !IsDictionaryOpen;
            if (IsDictionaryOpen)
            {
                _ = SwitchDictionaryField("Writer");
            }
        }

        [RelayCommand]
        private async Task SwitchDictionaryField(string fieldName)
        {
            DictionaryFieldName = fieldName;
            var item = DictionaryFieldItems.FirstOrDefault(f => f.FieldName == fieldName);
            DictionaryFieldDisplayName = item?.DisplayName ?? fieldName;

            // 更新选中状态
            foreach (var f in DictionaryFieldItems)
                f.IsSelected = f.FieldName == fieldName;

            DictionaryValues = new ObservableCollection<string>(
                await _historyService.GetFieldHistoryAsync(fieldName));
            NewDictionaryValue = string.Empty;
        }

        [RelayCommand]
        private async Task AddDictionaryValue()
        {
            if (string.IsNullOrWhiteSpace(NewDictionaryValue)) return;

            // 支持逗号分隔批量添加
            var items = SplitCommaSeparated(NewDictionaryValue);
            foreach (var item in items)
            {
                await _historyService.AddFieldHistoryAsync(DictionaryFieldName, item);
            }

            DictionaryValues = new ObservableCollection<string>(
                await _historyService.GetFieldHistoryAsync(DictionaryFieldName));
            NewDictionaryValue = string.Empty;

            await LoadHistoryData();
        }

        [RelayCommand]
        private async Task DeleteDictionaryValue(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;

            await _historyService.DeleteFieldHistoryAsync(DictionaryFieldName, value);
            DictionaryValues = new ObservableCollection<string>(
                await _historyService.GetFieldHistoryAsync(DictionaryFieldName));

            await LoadHistoryData();
        }

        public async Task DeleteDictionaryValuesAsync(List<string> values)
        {
            if (values == null || values.Count == 0) return;

            foreach (var value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                    await _historyService.DeleteFieldHistoryAsync(DictionaryFieldName, value);
            }

            DictionaryValues = new ObservableCollection<string>(
                await _historyService.GetFieldHistoryAsync(DictionaryFieldName));

            await LoadHistoryData();
        }

        private void UpdateWindowTitle()
        {
            if (CbzFiles.Count > 0)
                WindowTitle = $"CBZ漫画编辑器 - {CbzFiles.Count} 个文件";
            else
                WindowTitle = "CBZ漫画编辑器";
        }

        public async Task<ObservableCollection<string>> SearchHistoryAsync(string fieldName, string searchText)
        {
            var results = await _historyService.SearchFieldHistoryAsync(fieldName, searchText);
            return new ObservableCollection<string>(results);
        }
    }

    public partial class CbzFileItem : ObservableObject
    {
        [ObservableProperty] private string _filePath = string.Empty;
        [ObservableProperty] private string _fileName = string.Empty;
        [ObservableProperty] private string _directoryName = string.Empty;
        [ObservableProperty] private bool _isSelected;

        public override string ToString() => FileName;
    }

    public partial class CustomFieldItem : ObservableObject
    {
        [ObservableProperty] private string _fieldName = string.Empty;
        [ObservableProperty] private string _fieldValue = string.Empty;
    }

    public partial class DictionaryFieldItem : ObservableObject
    {
        [ObservableProperty] private string _fieldName = string.Empty;
        [ObservableProperty] private string _displayName = string.Empty;
        [ObservableProperty] private bool _isSelected;
    }
}
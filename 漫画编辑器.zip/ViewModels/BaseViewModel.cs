using CommunityToolkit.Mvvm.ComponentModel;

namespace ComicInfoEditor.ViewModels
{
    public partial class BaseViewModel : ObservableObject
    {
    }
}
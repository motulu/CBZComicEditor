using ComicInfoEditor.Models;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ComicInfoEditor.Services
{
    public class CbzService : ICbzService
    {
        private const string ComicInfoFileName = "ComicInfo.xml";

        public Task<ComicInfo> LoadComicInfoAsync(string filePath)
        {
            return Task.Run(() => LoadComicInfo(filePath));
        }

        public Task SaveComicInfoAsync(string filePath, ComicInfo comicInfo, bool createBackup = true)
        {
            return Task.Run(() => SaveComicInfo(filePath, comicInfo, createBackup));
        }

        public ComicInfo LoadComicInfo(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("CBZ文件不存在", filePath);

            using (var archive = ZipFile.OpenRead(filePath))
            {
                var entry = archive.GetEntry(ComicInfoFileName);
                if (entry == null)
                    return new ComicInfo();

                using (var stream = entry.Open())
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string xmlContent = reader.ReadToEnd();
                    return DeserializeComicInfo(xmlContent);
                }
            }
        }

        public void SaveComicInfo(string filePath, ComicInfo comicInfo, bool createBackup = true)
        {
            if (createBackup)
            {
                string backupPath = GetBackupPath(filePath);
                File.Copy(filePath, backupPath, true);
            }

            string xmlContent = SerializeComicInfo(comicInfo);
            string tempPath = filePath + ".tmp";

            try
            {
                // 使用临时文件方式：读取原文件所有条目，创建新ZIP，替换原文件
                using (var sourceArchive = ZipFile.OpenRead(filePath))
                using (var destArchive = ZipFile.Open(tempPath, ZipArchiveMode.Create))
                {
                    foreach (var entry in sourceArchive.Entries)
                    {
                        if (string.Equals(entry.Name, ComicInfoFileName, StringComparison.OrdinalIgnoreCase))
                            continue; // 跳过旧的ComicInfo.xml

                        var newEntry = destArchive.CreateEntry(entry.FullName, CompressionLevel.Optimal);
                        using (var sourceStream = entry.Open())
                        using (var destStream = newEntry.Open())
                        {
                            sourceStream.CopyTo(destStream);
                        }
                    }

                    // 添加新的ComicInfo.xml
                    var comicInfoEntry = destArchive.CreateEntry(ComicInfoFileName, CompressionLevel.Optimal);
                    using (var writer = new StreamWriter(comicInfoEntry.Open(), new UTF8Encoding(false)))
                    {
                        writer.Write(xmlContent);
                    }
                }

                // 替换原文件
                File.Delete(filePath);
                File.Move(tempPath, filePath);
            }
            catch
            {
                // 清理临时文件
                if (File.Exists(tempPath))
                    File.Delete(tempPath);
                throw;
            }
        }

        public bool IsValidCbz(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    return false;

                var extension = Path.GetExtension(filePath).ToLowerInvariant();
                if (extension != ".cbz" && extension != ".zip")
                    return false;

                using (var archive = ZipFile.OpenRead(filePath))
                {
                    return archive.Entries.Any(e =>
                        e.Name.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase) ||
                        e.Name.EndsWith(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                        e.Name.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
                        e.Name.EndsWith(".webp", StringComparison.OrdinalIgnoreCase) ||
                        e.Name.EndsWith(".gif", StringComparison.OrdinalIgnoreCase) ||
                        e.Name.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase));
                }
            }
            catch
            {
                return false;
            }
        }

        public string GetBackupPath(string filePath)
        {
            var dir = Path.GetDirectoryName(filePath);
            var name = Path.GetFileNameWithoutExtension(filePath);
            var ext = Path.GetExtension(filePath);
            var backupName = $"{name}_backup_{DateTime.Now:yyyyMMddHHmmss}{ext}";
            return Path.Combine(dir ?? string.Empty, backupName);
        }

        private ComicInfo DeserializeComicInfo(string xmlContent)
        {
            try
            {
                var doc = XDocument.Parse(xmlContent);
                var root = doc.Root;
                if (root == null) return new ComicInfo();

                var comicInfo = new ComicInfo();
                foreach (var element in root.Elements())
                {
                    string name = element.Name.LocalName;
                    string value = element.Value;

                    switch (name)
                    {
                        case "Series": comicInfo.Series = value; break;
                        case "LocalizedSeries": comicInfo.LocalizedSeries = value; break;
                        case "SeriesSort": comicInfo.SeriesSort = value; break;
                        case "Writer": comicInfo.Writer = value; break;
                        case "Publisher": comicInfo.Publisher = value; break;
                        case "Translator": comicInfo.Translator = value; break;
                        case "Title": comicInfo.Title = value; break;
                        case "Number": comicInfo.Number = value; break;
                        case "Count": comicInfo.Count = value; break;
                        case "Volume": comicInfo.Volume = value; break;
                        case "StoryArc": comicInfo.StoryArc = value; break;
                        case "StoryArcNumber": comicInfo.StoryArcNumber = value; break;
                        case "SeriesGroup": comicInfo.SeriesGroup = value; break;
                        case "RelatedWorks": comicInfo.RelatedWorks = value; break;
                        case "Summary": comicInfo.Summary = value; break;
                        case "Notes": comicInfo.Notes = value; break;
                        case "Genre": comicInfo.Genre = value; break;
                        case "Tags": comicInfo.Tags = value; break;
                        case "Web": comicInfo.Web = value; break;
                        case "PageCount": if (int.TryParse(value, out int pc)) comicInfo.PageCount = pc; break;
                        case "Year": if (int.TryParse(value, out int y)) comicInfo.Year = y; break;
                        case "Month": if (int.TryParse(value, out int m)) comicInfo.Month = m; break;
                        case "Day": if (int.TryParse(value, out int d)) comicInfo.Day = d; break;
                        default:
                            // 自定义字段
                            var doc2 = new XmlDocument();
                            var importedNode = doc2.ImportNode(element.ToXmlNode(doc2)!, true);
                            comicInfo.CustomFields.Add((XmlElement)importedNode);
                            break;
                    }
                }
                return comicInfo;
            }
            catch
            {
                return new ComicInfo();
            }
        }

        private string SerializeComicInfo(ComicInfo comicInfo)
        {
            var doc = new XDocument(new XDeclaration("1.0", "utf-8", null));
            var root = new XElement("ComicInfo");

            AddElement(root, "Series", comicInfo.Series);
            AddElement(root, "LocalizedSeries", comicInfo.LocalizedSeries);
            AddElement(root, "SeriesSort", comicInfo.SeriesSort);
            AddElement(root, "Writer", comicInfo.Writer);
            AddElement(root, "Publisher", comicInfo.Publisher);
            AddElement(root, "Translator", comicInfo.Translator);
            AddElement(root, "Title", comicInfo.Title);
            AddElement(root, "Number", comicInfo.Number);
            AddElement(root, "Count", comicInfo.Count);
            AddElement(root, "Volume", comicInfo.Volume);
            AddElement(root, "StoryArc", comicInfo.StoryArc);
            AddElement(root, "StoryArcNumber", comicInfo.StoryArcNumber);
            AddElement(root, "SeriesGroup", comicInfo.SeriesGroup);
            AddElement(root, "RelatedWorks", comicInfo.RelatedWorks);
            AddElement(root, "Summary", comicInfo.Summary);
            AddElement(root, "Notes", comicInfo.Notes);
            AddElement(root, "Genre", comicInfo.Genre);
            AddElement(root, "Tags", comicInfo.Tags);
            AddElement(root, "Web", comicInfo.Web);
            if (comicInfo.PageCount != 0) AddElement(root, "PageCount", comicInfo.PageCount.ToString());
            if (comicInfo.Year != 0) AddElement(root, "Year", comicInfo.Year.ToString());
            if (comicInfo.Month != 0) AddElement(root, "Month", comicInfo.Month.ToString());
            if (comicInfo.Day != 0) AddElement(root, "Day", comicInfo.Day.ToString());

            // 自定义字段
            if (comicInfo.CustomFields != null)
            {
                foreach (var field in comicInfo.CustomFields)
                {
                    try
                    {
                        var element = XElement.Parse(field.OuterXml);
                        root.Add(element);
                    }
                    catch
                    {
                        // 跳过无法解析的元素
                    }
                }
            }

            doc.Add(root);

            var utf8NoBom = new UTF8Encoding(false);
            var settings = new XmlWriterSettings
            {
                Encoding = utf8NoBom,
                Indent = true,
                IndentChars = "  ",
                OmitXmlDeclaration = false
            };

            using (var ms = new MemoryStream())
            {
                using (var writer = XmlWriter.Create(ms, settings))
                {
                    doc.Save(writer);
                }
                return utf8NoBom.GetString(ms.ToArray());
            }
        }

        private static void AddElement(XElement parent, string name, string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                parent.Add(new XElement(name, value));
            }
        }
    }

    public static class XElementExtensions
    {
        public static XmlNode? ToXmlNode(this XElement element, XmlDocument doc)
        {
            using (var reader = element.CreateReader())
            {
                return doc.ReadNode(reader) ?? doc.CreateElement(element.Name.LocalName);
            }
        }
    }
}
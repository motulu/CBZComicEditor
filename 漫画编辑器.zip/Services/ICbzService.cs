using ComicInfoEditor.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ComicInfoEditor.Services
{
    public interface ICbzService
    {
        Task<ComicInfo> LoadComicInfoAsync(string filePath);
        Task SaveComicInfoAsync(string filePath, ComicInfo comicInfo, bool createBackup = true);
        ComicInfo LoadComicInfo(string filePath);
        void SaveComicInfo(string filePath, ComicInfo comicInfo, bool createBackup = true);
        bool IsValidCbz(string filePath);
        string GetBackupPath(string filePath);
    }
}
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ComicInfoEditor.Services
{
    public interface IHistoryService
    {
        Task<List<string>> GetFieldHistoryAsync(string fieldName);
        Task AddFieldHistoryAsync(string fieldName, string value);
        Task DeleteFieldHistoryAsync(string fieldName, string value);
        Task<List<string>> SearchFieldHistoryAsync(string fieldName, string searchText, int limit = 10);
        List<string> GetFieldHistory(string fieldName);
        void AddFieldHistory(string fieldName, string value);
        void DeleteFieldHistory(string fieldName, string value);
        List<string> SearchFieldHistory(string fieldName, string searchText, int limit = 10);
        void Initialize();
    }
}
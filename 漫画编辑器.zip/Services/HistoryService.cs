using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;

namespace ComicInfoEditor.Services
{
    public class HistoryService : IHistoryService
    {
        private readonly string _connectionString;
        private const int MaxHistoryPerField = 100;

        public HistoryService()
        {
            string appDataPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "ComicInfoEditor");
            Directory.CreateDirectory(appDataPath);

            string dbPath = Path.Combine(appDataPath, "history.db");
            _connectionString = $"Data Source={dbPath};Version=3;";
        }

        public void Initialize()
        {
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        CREATE TABLE IF NOT EXISTS FieldHistory (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            FieldName TEXT NOT NULL,
                            Value TEXT NOT NULL,
                            CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
                        );
                        CREATE INDEX IF NOT EXISTS IX_FieldHistory_FieldName 
                        ON FieldHistory(FieldName);
                        CREATE UNIQUE INDEX IF NOT EXISTS IX_FieldHistory_FieldName_Value 
                        ON FieldHistory(FieldName, Value);
                    ";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public Task<List<string>> GetFieldHistoryAsync(string fieldName)
        {
            return Task.Run(() => GetFieldHistory(fieldName));
        }

        public Task AddFieldHistoryAsync(string fieldName, string value)
        {
            return Task.Run(() => AddFieldHistory(fieldName, value));
        }

        public Task DeleteFieldHistoryAsync(string fieldName, string value)
        {
            return Task.Run(() => DeleteFieldHistory(fieldName, value));
        }

        public Task<List<string>> SearchFieldHistoryAsync(string fieldName, string searchText, int limit = 10)
        {
            return Task.Run(() => SearchFieldHistory(fieldName, searchText, limit));
        }

        public List<string> GetFieldHistory(string fieldName)
        {
            var results = new List<string>();
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT OR REPLACE INTO FieldHistory (FieldName, Value, CreatedAt)
                        VALUES (@fieldName, @value, 
                            COALESCE((SELECT CreatedAt FROM FieldHistory WHERE FieldName = @fieldName AND Value = @value), CURRENT_TIMESTAMP));
                        
                        SELECT Value FROM FieldHistory 
                        WHERE FieldName = @fieldName2 
                        ORDER BY CreatedAt DESC 
                        LIMIT @limit;
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@value", ""); // placeholder
                    cmd.Parameters.AddWithValue("@fieldName2", fieldName);
                    cmd.Parameters.AddWithValue("@limit", MaxHistoryPerField);
                    // We need to split this into two commands
                }
            }

            // Simplified approach
            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT Value FROM FieldHistory 
                        WHERE FieldName = @fieldName 
                        ORDER BY CreatedAt DESC 
                        LIMIT @limit;
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@limit", MaxHistoryPerField);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            results.Add(reader.GetString(0));
                        }
                    }
                }
            }
            return results;
        }

        public void AddFieldHistory(string fieldName, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT OR REPLACE INTO FieldHistory (FieldName, Value, CreatedAt)
                        VALUES (@fieldName, @value, CURRENT_TIMESTAMP);
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@value", value.Trim());
                    cmd.ExecuteNonQuery();
                }

                // Clean up old entries
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        DELETE FROM FieldHistory 
                        WHERE FieldName = @fieldName AND Id NOT IN (
                            SELECT Id FROM FieldHistory 
                            WHERE FieldName = @fieldName2 
                            ORDER BY CreatedAt DESC 
                            LIMIT @limit
                        );
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@fieldName2", fieldName);
                    cmd.Parameters.AddWithValue("@limit", MaxHistoryPerField);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteFieldHistory(string fieldName, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        DELETE FROM FieldHistory 
                        WHERE FieldName = @fieldName AND Value = @value;
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@value", value.Trim());
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<string> SearchFieldHistory(string fieldName, string searchText, int limit = 10)
        {
            var results = new List<string>();
            if (string.IsNullOrWhiteSpace(searchText))
                return GetFieldHistory(fieldName);

            using (var connection = new SQLiteConnection(_connectionString))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = @"
                        SELECT Value FROM FieldHistory 
                        WHERE FieldName = @fieldName AND Value LIKE @searchText 
                        ORDER BY CreatedAt DESC 
                        LIMIT @limit;
                    ";
                    cmd.Parameters.AddWithValue("@fieldName", fieldName);
                    cmd.Parameters.AddWithValue("@searchText", $"%{searchText}%");
                    cmd.Parameters.AddWithValue("@limit", limit);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            results.Add(reader.GetString(0));
                        }
                    }
                }
            }
            return results;
        }
    }
}
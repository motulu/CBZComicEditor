using System.Collections.Generic;
using System.Xml.Serialization;

namespace ComicInfoEditor.Models
{
    [XmlRoot("ComicInfo")]
    public class ComicInfo
    {
        [XmlElement("Series")]
        public string Series { get; set; }

        [XmlElement("LocalizedSeries")]
        public string LocalizedSeries { get; set; }

        [XmlElement("SeriesSort")]
        public string SeriesSort { get; set; }

        [XmlElement("Writer")]
        public string Writer { get; set; }

        [XmlElement("Publisher")]
        public string Publisher { get; set; }

        [XmlElement("Translator")]
        public string Translator { get; set; }

        [XmlElement("Title")]
        public string Title { get; set; }

        [XmlElement("Number")]
        public string Number { get; set; }

        [XmlElement("Count")]
        public string Count { get; set; }

        [XmlElement("Volume")]
        public string Volume { get; set; }

        [XmlElement("StoryArc")]
        public string StoryArc { get; set; }

        [XmlElement("StoryArcNumber")]
        public string StoryArcNumber { get; set; }

        [XmlElement("SeriesGroup")]
        public string SeriesGroup { get; set; }

        [XmlElement("RelatedWorks")]
        public string RelatedWorks { get; set; }

        [XmlElement("Summary")]
        public string Summary { get; set; }

        [XmlElement("Notes")]
        public string Notes { get; set; }

        [XmlElement("Genre")]
        public string Genre { get; set; }

        [XmlElement("Tags")]
        public string Tags { get; set; }

        [XmlElement("Web")]
        public string Web { get; set; }

        [XmlElement("PageCount")]
        public int PageCount { get; set; }

        [XmlElement("Year")]
        public int Year { get; set; }

        [XmlElement("Month")]
        public int Month { get; set; }

        [XmlElement("Day")]
        public int Day { get; set; }

        [XmlIgnore]
        public bool PageCountSpecified => PageCount != 0;

        [XmlIgnore]
        public bool YearSpecified => Year != 0;

        [XmlIgnore]
        public bool MonthSpecified => Month != 0;

        [XmlIgnore]
        public bool DaySpecified => Day != 0;

        [XmlAnyElement]
        public List<System.Xml.XmlElement> CustomFields { get; set; } = new List<System.Xml.XmlElement>();

        public ComicInfo()
        {
            Series = string.Empty;
            LocalizedSeries = string.Empty;
            SeriesSort = string.Empty;
            Writer = string.Empty;
            Publisher = string.Empty;
            Translator = string.Empty;
            Title = string.Empty;
            Number = string.Empty;
            Count = string.Empty;
            Volume = string.Empty;
            StoryArc = string.Empty;
            StoryArcNumber = string.Empty;
            SeriesGroup = string.Empty;
            RelatedWorks = string.Empty;
            Summary = string.Empty;
            Notes = string.Empty;
            Genre = string.Empty;
            Tags = string.Empty;
            Web = string.Empty;
        }
    }
}
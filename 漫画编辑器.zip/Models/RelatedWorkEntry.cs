using System.Collections.Generic;
using System.Linq;

namespace ComicInfoEditor.Models
{
    public class RelatedWorkEntry
    {
        public string WorkName { get; set; } = string.Empty;
        public string Relation { get; set; } = string.Empty;

        public RelatedWorkEntry() { }

        public RelatedWorkEntry(string workName, string relation)
        {
            WorkName = workName;
            Relation = relation;
        }

        public override string ToString()
        {
            return $"{WorkName}[{Relation}]";
        }

        public static List<RelatedWorkEntry> Parse(string relatedWorksString)
        {
            var entries = new List<RelatedWorkEntry>();
            if (string.IsNullOrWhiteSpace(relatedWorksString))
                return entries;

            int i = 0;
            while (i < relatedWorksString.Length)
            {
                int bracketStart = relatedWorksString.IndexOf('[', i);
                if (bracketStart < 0) break;

                string name = relatedWorksString.Substring(i, bracketStart - i).Trim();
                int bracketEnd = relatedWorksString.IndexOf(']', bracketStart);
                if (bracketEnd < 0) break;

                string relation = relatedWorksString.Substring(bracketStart + 1, bracketEnd - bracketStart - 1).Trim();
                entries.Add(new RelatedWorkEntry(name, relation));
                i = bracketEnd + 1;
                if (i < relatedWorksString.Length && relatedWorksString[i] == ',')
                    i++;
            }
            return entries;
        }

        public static string ToString(List<RelatedWorkEntry> entries)
        {
            return string.Join(",", entries.Select(e => e.ToString()));
        }
    }
}
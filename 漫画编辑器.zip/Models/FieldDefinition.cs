namespace ComicInfoEditor.Models
{
    public class FieldDefinition
    {
        public string Name { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string XmlElement { get; set; } = string.Empty;
        public FieldType Type { get; set; } = FieldType.Text;
        public bool IsCustom { get; set; } = false;
        public bool HasHistory { get; set; } = false;
    }

    public enum FieldType
    {
        Text,
        Number,
        Date,
        Multiline,
        RelatedWorks
    }
}
# CBZ 漫画编辑器 (CBZ Comic Editor)

一款运行于 Windows 10/11 的 CBZ 格式漫画元数据编辑器，可对 CBZ 文件内的 `ComicInfo.xml` 进行增删改操作。

## 功能特性

- **单文件 / 批量编辑** — 支持打开单个 CBZ 文件，也支持扫描文件夹批量导入
- **多选批量修改** — Ctrl+点击 或 Shift+拖动 多选文件，一次修改全部选中文件的字段
- **字典管理** — 内置作者、社团/出版社、翻译、分类、标签等字段的字典，支持添加、删除、多选批量删除
- **自动补全** — 输入时根据字典数据自动补全，逗号分隔的多值字段同样支持
- **相关作品** — 结构化编辑相关作品信息（作品名 + 关系）
- **自定义字段** — 支持编辑器中未列出的自定义字段
- **完整窗口管理** — 最小化 / 最大化 / 还原 / 关闭 / 窗口缩放 / 全屏模式
- **DPI 自适应** — 适配不同分辨率和缩放比例的屏幕
- **数据持久化** — 字典数据通过 SQLite 本地存储，编辑记录不丢失

## 截图

![界面截图](捕获.JPG)

## 系统要求

- Windows 10 / 11 (x64)
- .NET 8.0 运行时

## 技术栈

- .NET 8 + WPF (MVVM 模式)
- CommunityToolkit.Mvvm
- System.IO.Compression (ZIP/CBZ 操作)
- SQLite (字典数据持久化)

## 项目结构

```
ComicInfoEditor/
├── App.xaml                    # 应用程序入口
├── App.xaml.cs
├── AssemblyInfo.cs             # 程序集信息
├── ComicInfoEditor.csproj      # 项目文件
├── MainWindow.xaml             # 主窗口界面
├── MainWindow.xaml.cs          # 主窗口逻辑
├── app.ico                     # 程序图标
├── Controls/
│   ├── AutoCompleteTextBox.xaml         # 自动补全输入框
│   ├── AutoCompleteTextBox.xaml.cs
│   ├── RelatedWorksEditorControl.xaml   # 相关作品编辑控件
│   └── RelatedWorksEditorControl.xaml.cs
├── Models/
│   ├── ComicInfo.cs            # ComicInfo.xml 数据模型
│   ├── FieldDefinition.cs      # 字段定义
│   └── RelatedWorkEntry.cs     # 相关作品条目
├── Services/
│   ├── ICbzService.cs          # CBZ 服务接口
│   ├── CbzService.cs           # CBZ 文件读写实现
│   ├── IHistoryService.cs      # 历史记录服务接口
│   └── HistoryService.cs       # SQLite 历史记录实现
├── ViewModels/
│   ├── BaseViewModel.cs        # MVVM 基类
│   └── MainViewModel.cs        # 主窗口 ViewModel
└── Converters/
    └── BoolToVisibilityConverter.cs  # 布尔值转换器
```

## 构建

```bash
dotnet build --configuration Release
```

输出目录：`bin/Release/net8.0-windows/`

## 许可证

本项目采用 [GNU Affero General Public License v3.0 (AGPL-3.0)](LICENSE)。任何基于本项目的修改和衍生作品必须同样以 AGPL-3.0 开源，包括通过网络提供服务（SaaS）的场景。
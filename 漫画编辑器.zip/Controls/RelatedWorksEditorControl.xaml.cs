using System.Windows.Controls;

namespace ComicInfoEditor.Controls
{
    public partial class RelatedWorksEditorControl : UserControl
    {
        public RelatedWorksEditorControl()
        {
            InitializeComponent();
        }
    }
}
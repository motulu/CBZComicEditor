using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ComicInfoEditor.Controls
{
    public partial class AutoCompleteTextBox : UserControl
    {
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(AutoCompleteTextBox),
                new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnTextPropertyChanged));

        private static void OnTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (AutoCompleteTextBox)d;
            // 当 Text 由绑定源（ViewModel）程序化设置时，标记为程序化变更
            // 如果 TextBox 已获得焦点（用户正在输入），则忽略此标记
            if (!control.InputTextBox.IsFocused)
            {
                control._programmaticChange = true;
                control.Dispatcher.BeginInvoke(new Action(() => control._programmaticChange = false),
                    System.Windows.Threading.DispatcherPriority.Loaded);
            }
        }

        public static readonly DependencyProperty SuggestionsProperty =
            DependencyProperty.Register("Suggestions", typeof(ObservableCollection<string>), typeof(AutoCompleteTextBox),
                new PropertyMetadata(new ObservableCollection<string>()));

        public static readonly DependencyProperty FieldNameProperty =
            DependencyProperty.Register("FieldName", typeof(string), typeof(AutoCompleteTextBox),
                new PropertyMetadata(string.Empty));

        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public ObservableCollection<string> Suggestions
        {
            get => (ObservableCollection<string>)GetValue(SuggestionsProperty);
            set => SetValue(SuggestionsProperty, value);
        }

        public string FieldName
        {
            get => (string)GetValue(FieldNameProperty);
            set => SetValue(FieldNameProperty, value);
        }

        public event EventHandler<string>? TextSubmitted;

        private readonly ObservableCollection<string> _filteredSuggestions = new();
        private bool _suppressTextChanged;
        private bool _isApplyingSuggestion;
        private bool _suppressSelectionChanged;
        private bool _programmaticChange;
        private CancellationTokenSource? _lostFocusCts;

        public AutoCompleteTextBox()
        {
            InitializeComponent();
            SuggestionListBox.ItemsSource = _filteredSuggestions;
        }

        private void UpdateFilteredSuggestions(string filter)
        {
            _filteredSuggestions.Clear();
            if (string.IsNullOrEmpty(filter))
            {
                foreach (var s in Suggestions)
                    _filteredSuggestions.Add(s);
            }
            else
            {
                // 取最后一个逗号后的文本作为过滤条件
                int lastComma = filter.LastIndexOf(',');
                string searchText = lastComma >= 0 ? filter.Substring(lastComma + 1).TrimStart() : filter;

                if (string.IsNullOrEmpty(searchText))
                {
                    foreach (var s in Suggestions)
                        _filteredSuggestions.Add(s);
                }
                else
                {
                    var lowerFilter = searchText.ToLower();
                    foreach (var s in Suggestions)
                    {
                        if (s.ToLower().Contains(lowerFilter))
                            _filteredSuggestions.Add(s);
                    }
                }
            }
        }

        private void InputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_suppressTextChanged) return;
            if (_programmaticChange) return;

            var currentText = InputTextBox.Text;
            UpdateFilteredSuggestions(currentText);
            if (_filteredSuggestions.Count > 0)
            {
                CancelLostFocusClose();
                SuggestionPopup.IsOpen = true;
            }
            else
            {
                SuggestionPopup.IsOpen = false;
            }
        }

        private void ApplySuggestion(string value)
        {
            if (_isApplyingSuggestion) return;
            _isApplyingSuggestion = true;

            try
            {
                _suppressTextChanged = true;

                var currentText = InputTextBox.Text;
                string newText;

                if (string.IsNullOrEmpty(currentText))
                {
                    // 空文本：直接设置
                    newText = value + ",";
                }
                else
                {
                    int lastComma = currentText.LastIndexOf(',');
                    if (lastComma >= 0)
                    {
                        // 已有逗号：替换最后一个逗号后的内容
                        newText = currentText.Substring(0, lastComma + 1) + value + ",";
                    }
                    else if (value.StartsWith(currentText, StringComparison.OrdinalIgnoreCase))
                    {
                        // 当前文本是所选值的前缀（如输入"巨"选择"巨乳"）：替换
                        newText = value + ",";
                    }
                    else
                    {
                        // 当前文本是完整值（如"五纷纷呃"选择其他选项）：追加
                        newText = currentText + "," + value + ",";
                    }
                }

                Text = newText;
                InputTextBox.Text = newText;
                InputTextBox.CaretIndex = newText.Length;
                SuggestionPopup.IsOpen = false;
                CancelLostFocusClose();

                // 延迟设置焦点，在所有鼠标/键盘事件处理完毕后切换
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    InputTextBox.Focus();
                    Keyboard.Focus(InputTextBox);
                }), System.Windows.Threading.DispatcherPriority.Input);
            }
            finally
            {
                _suppressTextChanged = false;
                _isApplyingSuggestion = false;
            }
        }

        private void InputTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Down && SuggestionPopup.IsOpen && SuggestionListBox.Items.Count > 0)
            {
                _suppressSelectionChanged = true;
                SuggestionListBox.Focus();
                SuggestionListBox.SelectedIndex = 0;
                _suppressSelectionChanged = false;
                e.Handled = true;
            }
            else if (e.Key == Key.Enter)
            {
                TextSubmitted?.Invoke(this, Text);
                SuggestionPopup.IsOpen = false;
            }
            else if (e.Key == Key.OemComma || e.Key == Key.Divide)
            {
                // 逗号键：确保不被拦截，关闭弹窗让用户自由输入
                CancelLostFocusClose();
                // 不设置 e.Handled = true，让逗号正常输入
            }
        }

        private void InputTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (!SuggestionListBox.IsKeyboardFocusWithin)
            {
                CancelLostFocusClose();
                _lostFocusCts = new CancellationTokenSource();
                var token = _lostFocusCts.Token;
                System.Threading.Tasks.Task.Delay(200, token).ContinueWith(_ =>
                {
                    if (!token.IsCancellationRequested)
                    {
                        Application.Current.Dispatcher.Invoke(() => SuggestionPopup.IsOpen = false);
                    }
                }, TaskContinuationOptions.NotOnCanceled);
            }
        }

        private void CancelLostFocusClose()
        {
            if (_lostFocusCts != null)
            {
                _lostFocusCts.Cancel();
                _lostFocusCts.Dispose();
                _lostFocusCts = null;
            }
        }

        private void DropdownButton_Click(object sender, RoutedEventArgs e)
        {
            if (SuggestionPopup.IsOpen)
            {
                SuggestionPopup.IsOpen = false;
                return;
            }

            _suppressSelectionChanged = true;
            _filteredSuggestions.Clear();
            foreach (var s in Suggestions)
                _filteredSuggestions.Add(s);

            if (_filteredSuggestions.Count > 0)
            {
                SuggestionPopup.IsOpen = true;
            }
            _suppressSelectionChanged = false;
        }

        private void SuggestionListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 程序化选择（如下拉按钮、键盘导航）不触发 ApplySuggestion
            if (_suppressSelectionChanged || _isApplyingSuggestion) return;

            if (SuggestionListBox.SelectedItem is string selectedText)
            {
                ApplySuggestion(selectedText);
            }
        }

        private void SuggestionListBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (SuggestionListBox.SelectedItem is string selectedText)
                {
                    ApplySuggestion(selectedText);
                }
                e.Handled = true;
            }
            else if (e.Key == Key.Escape)
            {
                SuggestionPopup.IsOpen = false;
                InputTextBox.Focus();
                e.Handled = true;
            }
        }
    }
}